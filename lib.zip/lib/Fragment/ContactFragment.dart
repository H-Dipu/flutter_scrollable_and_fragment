//import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
class ContactFragment extends StatelessWidget {
  const ContactFragment({super.key});



  @override
  Widget build(BuildContext context) {
    return Container(
      child:  const Center(
        child: Text("Contact Fragment"),
      ) ,
    );
  }
}
