//import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class BalanceFragment extends StatelessWidget {
  const BalanceFragment({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Center(
        child: Text("Balance Fragment"),
      ),
    );
  }
}
