//import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class AlarmFragment extends StatelessWidget {
  const AlarmFragment({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: const Center(
        child: Text("Alarm Fragment"),
      ),
    );
  }
}
