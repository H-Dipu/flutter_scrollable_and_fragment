//import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
class PersonFragment extends StatelessWidget {
  const PersonFragment({super.key});



  @override
  Widget build(BuildContext context) {
    return Container(
      child:  const Center(
        child: Text("Person Fragment"),
      ) ,
    );
  }
}
